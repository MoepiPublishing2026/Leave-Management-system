<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'status',
        'department', // <-- Add this line
    ];

    protected $hidden = [
        'password',
    ];

    public function assignments()
    {
        return $this->hasMany(Assignment::class);
    }

    public function software()
    {
        return $this->belongsToMany(Software::class, 'assignments');
    }
}
