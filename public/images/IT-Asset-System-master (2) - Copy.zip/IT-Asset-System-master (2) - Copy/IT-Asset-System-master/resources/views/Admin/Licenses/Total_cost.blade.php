@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 0 0 0; /* offset for navbar */
    background-color: #3c4044ff;
  }

  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .content-container {
    margin-left: 0;
    padding: 0 14px 14px 14px;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 1000px;
  }

  thead {
    background: linear-gradient(135deg, #6366f1, #4338ca, #312e81); /* indigo gradient for total cost */
    color: white;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
    white-space: nowrap;
  }

  tbody tr:hover {
    background-color: #c7d2fe; /* lighter indigo on hover */
  }

  .text-center {
    text-align: center;
  }
</style>

<div class="navbar">Total Cost Spent</div>

<div class="content-container">
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>License Name</th>
          <th>Purchase Date</th>
          <th>Vendor</th>
          <th>Cost (R)</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        @forelse($licenses as $license)
        <tr>
          <td>{{ $license->software->name ?? 'N/A' }}</td>
          <td>{{ \Carbon\Carbon::parse($license->purchase_date ?? now())->format('d-m-Y') }}</td>
          <td>{{ $license->vendor ?? 'N/A' }}</td>
          <td>{{ number_format($license->total_licenses * $license->cost_per_license, 2, ',', ' ') }}</td>
          <td>Paid</td>
        </tr>
        @empty
        <tr>
          <td colspan="5" class="text-center">No licenses found.</td>
        </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection