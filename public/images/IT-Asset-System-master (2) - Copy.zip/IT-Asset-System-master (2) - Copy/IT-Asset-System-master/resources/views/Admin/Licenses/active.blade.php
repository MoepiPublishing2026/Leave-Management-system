@extends('layouts.admin')

@section('content')
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 0 0 0; /* offset for navbar */
    background-color: #3c4044ff;
  }

  /* Fixed navbar */
  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .content-container {
    margin-left: 0;
    padding: 0 14px 14px 14px;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 1200px;
  }

  thead {
     background-color: #10b981;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
    white-space: nowrap;
  }

  tbody tr:hover {
     background: linear-gradient(135deg, #b1f5deff);
      color: white; 
  }

  /* Status badge styling */
  .status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: capitalize;
  }
  .status-active {
    background-color: #dcfce7;
    color: #22c55e;
  }
 
</style>

<div class="navbar">Active Licenses</div>

<div class="content-container">
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>License Name</th>
          <th>Assigned To</th>
          <th>Department</th>
          <th>Manufacturer</th>
          <th>Expiry Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        @forelse($licenses as $license)
          <tr>
            <td>{{ $license->software->name }}</td>
            <td>{{ $license->user?->name ?? 'Unassigned' }}</td>
            <td>{{ $license->user?->department?->name ?? 'N/A' }}</td>
            <td>{{ $license->manufacturer }}</td>
            <td>{{ \Carbon\Carbon::parse($license->expiry_date)->format('d-m-Y') }}</td>
            <td>
              <span class="status-badge {{ $license->status === 'active' ? 'status-active' : 'status-inactive' }}">
                {{ ucfirst($license->status) }}
              </span>
            </td>
          </tr>
        @empty
          <tr>
            <td colspan="6" class="text-center">No active licenses found.</td>
          </tr>
        @endforelse
      </tbody>
    </table>
  </div>
</div>
@endsection