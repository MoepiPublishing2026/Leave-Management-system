<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard</title>
    @vite('resources/css/app.css')
    <style>
        /* Sidebar styling */
        aside {
             position: fixed;
    top: 0;
    left: 0;
    width: 256px;
    height: 100vh;
    background-color: white;
            padding: 1rem;
            box-shadow: 4px 0 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            align-items: center;
            
        }
        aside .logo-container {
            margin-bottom: 2rem;
            width: 100%;
            text-align: center;
        }
        aside .logo-container img {
            max-height: 190px;
            width: 200px;
            user-select: none;
            object-fit: contain;
        }
            aside ul {
    list-style: none;
    padding: 40px 0 0 0;
    margin: 0;
    width: 100%;
}
        aside ul li {
            margin-bottom: 1rem;
        }
        aside ul li a {
            color: #374151; /* Tailwind gray-700 */
            text-decoration: none;
            font-weight: 600;
            display: block;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        aside ul li a:hover,
        aside ul li a:focus {
            color: #261f38ff; /* Tailwind yellow-400 */
            background-color: #aea6c5ff; /* Tailwind yellow-100 */
        }
       .logout-button {
    background: none;
    border: none;
    color: #374151;
    font-weight: 600;
    padding: 0.5rem 1rem;
    width: 100%;
    text-align: left;
    cursor: pointer;
    border-radius: 0.375rem;
    transition: background-color 0.2s ease;
}

.logout-button:hover {
    color: #261f38;
    background-color: #aea6c5;
}
/* Style for submenu container */
aside ul ul {
    padding-left: 1.5rem;  /* indent submenu */
    background-color: #fcfcfcff; /* light background different from main menu */
    border-radius: 6px;
    margin-top: 0.5rem;
}

/* Style for submenu links */
aside ul ul li a {
    color: #5c0d0dff;          /* darker gray for submenu links */
    font-weight: 500;        /* slightly lighter font weight */
    padding: 0.4rem 1rem;    /* adjusted padding */
    border-radius: 6px;
    display: block;
    transition: background-color 0.3s ease, color 0.3s ease;
}

/* Hover effect for submenu */
aside ul ul li a:hover {
    background-color: #f5c8caff; /* pastel purple shade, different from main menu */
    color: #6d1b21ff;             /* dark text on hover */
}

        /* Body and shell layout */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #393a3bff; /* gray background */
            color: #1f2937; /* gray-800 */
        }
        .flex {
           display: block;
        }
        main {
           margin-left: 256px; /* leave space for sidebar */
    padding: 1.5rem;
    background-color: #ebeceeff;
    min-height: 100vh;
        }
    </style>
</head>
<body>
    <div class="flex">
        <!-- Sidebar -->
   <aside>
    <div class="logo-container">
        <img src="{{ asset('images/asset-logo.jpg') }}" alt="Asset Logo" />
    </div>

    <ul>
        <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
        <li>
            <a href="#softwareSubmenu" onclick="event.preventDefault(); toggleSubmenu()" aria-expanded="false">
                Software
            </a>
            <ul id="softwareSubmenu" style="display:none; list-style:none; padding-left: 1rem; margin-top: 0.5rem;">
                <li><a href="{{ route('admin.software.index') }}">All Softwares</a></li>
                <li><a href="{{ route('admin.software.assigned') }}">Assigned</a></li>
                <li><a href="{{ route('admin.software.unassigned') }}">Unassigned</a></li>

            </ul>
        </li>
        <li><a href="{{ route('admin.users.index') }}">Users</a></li>

        <li>
            <form method="POST" action="{{ route('logout') }}">
              @csrf
           <button type="submit" class="logout-button">Logout</button>
    </form>
    </li>

    </ul>
</aside>

<script>
    function toggleSubmenu() {
        const submenu = document.getElementById('softwareSubmenu');
        if (submenu.style.display === 'none' || submenu.style.display === '') {
            submenu.style.display = 'block';
        } else {
            submenu.style.display = 'none';
        }
    }
</script>


        <!-- Main content -->
        <main>
            @yield('content')
        </main>
    </div>

    @stack('scripts')
</body>
</html>
