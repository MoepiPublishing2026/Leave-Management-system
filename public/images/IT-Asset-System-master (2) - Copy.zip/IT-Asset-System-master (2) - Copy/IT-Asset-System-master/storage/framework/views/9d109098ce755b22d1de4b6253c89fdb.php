

<?php $__env->startSection('content'); ?>
<style>
  body {
    font-family: Arial, sans-serif;
    color: black;
    margin: 0;
    padding: 86px 0 0 0; /* offset for navbar */
    background-color: #3c4044ff;
  }

  /* Fixed navbar */
  .navbar {
    position: fixed;
    top: 0;
    left: 256px;
    width: calc(100vw - 256px);
    height: 86px;
    background-color: white;
    color: black;
    display: flex;
    align-items: center;
    padding: 0 24px;
    font-weight: 600;
    font-size: 1.5rem;
    box-shadow: 0 2px 6px -2px rgba(0,0,0,0.15);
    z-index: 1000;
  }

  .content-container {
    margin-left: 0;
    padding: 0 14px 14px 14px;
  }

  .table-container {
    margin-top: 20px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    overflow-x: auto;
    padding: 1rem;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    color: #222;
    min-width: 1200px;
  }

  thead {
     background-color: #10b981;
    font-weight: 700;
    border-bottom: 2px solid #ccc;
    text-align: left;
  }

  th, td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #e5e7eb;
    vertical-align: middle;
    white-space: nowrap;
  }

  tbody tr:hover {
     background: linear-gradient(135deg, #b1f5deff);
      color: white; 
  }

  /* Status badge styling */
  .status-badge {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: capitalize;
  }
  .status-active {
    background-color: #dcfce7;
    color: #22c55e;
  }
 
</style>

<div class="navbar">Active Licenses</div>

<div class="content-container">
  <div class="table-container">
    <table>
      <thead>
        <tr>
          <th>License Name</th>
          <th>Assigned To</th>
          <th>Department</th>
          <th>Manufacturer</th>
          <th>Expiry Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td><?php echo e($license->software->name); ?></td>
            <td><?php echo e($license->user?->name ?? 'Unassigned'); ?></td>
            <td><?php echo e($license->user?->department?->name ?? 'N/A'); ?></td>
            <td><?php echo e($license->manufacturer); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($license->expiry_date)->format('d-m-Y')); ?></td>
            <td>
              <span class="status-badge <?php echo e($license->status === 'active' ? 'status-active' : 'status-inactive'); ?>">
                <?php echo e(ucfirst($license->status)); ?>

              </span>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="6" class="text-center">No active licenses found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\IT-Asset-System-master (2) - Copy\IT-Asset-System-master\resources\views/admin/licenses/active.blade.php ENDPATH**/ ?>